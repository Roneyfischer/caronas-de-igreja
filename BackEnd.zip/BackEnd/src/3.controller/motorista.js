import dbMethod from "../1.model/DAL/dbMethod.js";

import motoristaService from "../2. Service/motoristaService.js";

const motorista = {
  ofertarCarona: async (reqBody) => {
    const { passageiroId, nome, celular } = reqBody;

    if (!passageiroId) {
      return { message: `Escolha um passageiro para dar carona!` };
    }
    if (!nome) {
      return { message: `Nome é obrigatório` };
    }

    if (!celular) {
      return { message: `Celular é obrigatório` };
    }

    return await motoristaService.ofertarCarona(passageiroId, nome, celular);
  },

  verCarona: async () => {
    return await passageiroService.verCaronas();
  },
};

export default motorista;
