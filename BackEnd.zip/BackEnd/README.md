Creiei esta estrutura pra ter um ponto de partida no desenvolvimento a partir do express
