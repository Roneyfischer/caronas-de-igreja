import dbMethod from "../1.model/DAL/dbMethod.js";

import passageiroService from "../2. Service/passageiroService.js";

const passageiro = {
  registrarPedidoCarona: async (reqBody) => {
    const {
      nome,
      numVagas,
      bairroResidencia,
      cidadeResidencia,
      estadoResidencia,
      celular,
    } = reqBody;

    if (!nome) {
      return { message: `Nome é obrigatório` };
    }
    if (!numVagas) {
      return { message: `Número de vagas é obrigatório` };
    }
    if (!bairroResidencia) {
      return { message: `Bairro é obrigatório` };
    }
    if (!cidadeResidencia) {
      return { message: `Cidade é obrigatório` };
    }
    if (!estadoResidencia) {
    }
    if (!celular) {
      return { message: `Celular é obrigatório` };
    }

    return await passageiroService.registrarPedidoCarona(
      nome,
      numVagas,
      bairroResidencia,
      cidadeResidencia,
      "PR",
      celular
    );
  },

  verCarona: async () => {
    return await passageiroService.verCaronas();
  },
};

export default passageiro;
