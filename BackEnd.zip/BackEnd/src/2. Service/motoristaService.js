import dbMethod from "../1.model/DAL/dbMethod.js";

const motoristaService = {
  ofertarCarona: async (passageiroId, nome, celular) => {
    const table = "caronas";
    const fieldName1 = "motoristanome";
    const fieldValue1 = [nome];
    const fieldName2 = "motoristacelular";
    const fieldValue2 = [celular];
    const nameItenToSearch = "id";
    const valueItenToSearch = passageiroId;
    console.log(passageiroId, nome, celular);
    await dbMethod.update(
      table,
      nameItenToSearch,
      valueItenToSearch,
      fieldName1,
      fieldValue1
    );

    return await dbMethod.update(
      table,
      nameItenToSearch,
      valueItenToSearch,
      fieldName2,
      fieldValue2
    );
  },
  verCaronas: async () => {
    const tableName = "caronas";
    return await dbMethod.readAll(tableName);
  },
};

export default motoristaService;
