import dbMethod from "../1.model/DAL/dbMethod.js";

const passageiroService = {
  registrarPedidoCarona: async (
    nome,
    numVagas,
    bairroResidencia,
    cidadeResidencia,
    estadoResidencia,
    celular
  ) => {
    const table = "caronas";
    const fieldName = `"nome", "numvagas", "bairro", "cidade", "estado", "celular"`;
    const fieldValue = [
      nome,
      numVagas,
      bairroResidencia,
      cidadeResidencia,
      estadoResidencia,
      celular,
    ];

    return await dbMethod.add(table, fieldName, fieldValue);
  },

  verCaronas: async () => {
    const tableName = "caronas";
    return await dbMethod.readAll(tableName);
  },

  
};

export default passageiroService;
