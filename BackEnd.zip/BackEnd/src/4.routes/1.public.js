import express from "express";
import passageiro from "../3.controller/passageiro.js";
import motorista from "../3.controller/motorista.js";

const homePage = express.Router();

homePage.get("/verCaronas", async (req, res) => {
  console.log("> [route.public]");

  console.log("> [route.homePage.get]");
  const reqBody = req.body;
  const getAllOnDbReturn = await passageiro.verCarona();
  return res
    .status(200)
    .json({ message: "sucsess", content: getAllOnDbReturn.dataFinded });
});

homePage.post("/pedirCarona", async (req, res) => {
  console.log("> [route.public]");
  console.log("> [route.homePage.post]");

  const reqBody = req.body;
  const userPassanger = await passageiro.registrarPedidoCarona(reqBody);

  return res.status(200).json({ content: userPassanger });
});

homePage.post("/ofertarCarona", async (req, res) => {
  console.log("> [route.public]");
  console.log("> [route.homePage.post]");

  const reqBody = req.body;
  const userPassanger = await motorista.ofertarCarona(reqBody);

  return res.status(200).json({ content: userPassanger });
});

export default homePage;
